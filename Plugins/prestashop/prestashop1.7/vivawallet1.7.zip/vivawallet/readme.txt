Latest stable version of Viva Wallet for PrestaShop 1.7. To view download and installation instructions, see https://developer.vivawallet.com/e-commerce-plugins/prestashop1.7/.
