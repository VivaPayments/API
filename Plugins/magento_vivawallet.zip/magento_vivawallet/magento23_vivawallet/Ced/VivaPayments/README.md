Latest stable version of Viva Wallet Smart Checkout plugin for Magento 2.3.

To view download and installation instructions, please refer to [developer portal](https://developer.vivawallet.com/plugins/magento/).
